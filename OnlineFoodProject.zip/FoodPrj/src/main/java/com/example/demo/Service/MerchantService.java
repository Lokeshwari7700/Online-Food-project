package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.MerchantDTO;
import com.example.demo.DTO.MerchantSaveDTO;
import com.example.demo.Model.Merchant;

public interface MerchantService {
	String addMerchant(MerchantSaveDTO merchantSaveDTO );
	List<MerchantDTO>getAllMerchant();
	Merchant updateMerchant(Merchant merchant, int id);
	boolean deleteMerchant(int id);

}
