package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.example.demo.DTO.OrderDetailsDTO;
import com.example.demo.DTO.OrderDetailsSaveDTO;
import com.example.demo.Model.OrderDetails;
import com.example.demo.Repository.OrderDetailsRepo;

@Service
public class OrderDetailsIMPL implements OrderDetailsService {
	@Autowired
	private OrderDetailsRepo orderrepo;

	@Override
	public String addOrderDetails(OrderDetailsSaveDTO orderdetailssaveDTO) {
		OrderDetails order = new OrderDetails(0,orderdetailssaveDTO.getFoodName(),orderdetailssaveDTO.getFoodprice(),
				orderdetailssaveDTO.getFoodimage(),orderdetailssaveDTO.getFoodQuantity(),orderdetailssaveDTO.getTotalPrice());
		orderrepo.save(order);
		return "Saved";
	}

	@Override
	public List<OrderDetailsDTO> getAllOrder() {
		List<OrderDetails> getOrder = orderrepo.findAll();
		List<OrderDetailsDTO> OrderDTOList = new ArrayList<>();
		for (OrderDetails a : getOrder) {
			OrderDetailsDTO orderDTO = new OrderDetailsDTO(a.getOrderId(),a.getFoodName(),a.getFoodprice(),a.getFoodimage(),a.getTotalPrice(),a.getFoodQuantity());
			OrderDTOList.add(orderDTO);
		}
		return OrderDTOList;
	}

	@Override
	public boolean deleteOrder(int id) {
		if (orderrepo.existsById(id)) {
			orderrepo.deleteById(id);
		} else {
			System.out.println("Order ID is Not found..");
		}
		return true;
	}

}

