package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.DTO.FoodDTO;
import com.example.demo.DTO.FoodSaveDTO;
import com.example.demo.Model.FoodList;
import com.example.demo.Service.FoodService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("api/v1/foodlist")
public class FoodController {
	
	@Autowired
	private FoodService foodService ;
	
	@PostMapping(path="/save")
	public String saveFood(@RequestBody FoodSaveDTO foodSaveDTO )
	{
		String id=foodService.addfood(foodSaveDTO);
		return id;
	}
	
	@GetMapping(path="/getAll")
	public List<FoodDTO>getAllFood()
	{
		List<FoodDTO>allFood=foodService.getAllFood();
		return allFood;
	}
	

	@PutMapping("update/{id}")
	public ResponseEntity<FoodList>updateFood(@PathVariable("id")int id,@RequestBody FoodList food)
	{
		return new ResponseEntity<FoodList>(foodService.updateFood(food, id),HttpStatus.OK);
	}
	
	@DeleteMapping(path="/deleteFood/{id}")
	public String deleteFood(@PathVariable(value="id")int id)
	{
		boolean deleteFood=foodService.deleteFood(id);
		return "deleted";
	}
	@GetMapping("{id}")
	public ResponseEntity<FoodList>getFoodById(@PathVariable("id")int id)
	{
	   return new ResponseEntity<FoodList>(foodService.getFoodById(id),HttpStatus.OK);
	}
}








