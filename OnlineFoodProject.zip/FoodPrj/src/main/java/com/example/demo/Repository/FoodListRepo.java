package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.FoodList;

public interface FoodListRepo extends JpaRepository<FoodList,Integer>{

}
